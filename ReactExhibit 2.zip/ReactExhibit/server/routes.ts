import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { batchItemCreationSchema, insertItemSchema, updateItemSchema, insertInspectionSchema, aiSummaryRequestSchema, aiSummaryResponseSchema } from "@shared/schema";
import QRCode from "qrcode";

export async function registerRoutes(app: Express): Promise<Server> {
  // Items routes
  app.get("/api/items", async (req, res) => {
    try {
      const items = await storage.getItems();
      res.json(items);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch items" });
    }
  });

  app.get("/api/items/:id", async (req, res) => {
    try {
      const item = await storage.getItem(req.params.id);
      if (!item) {
        return res.status(404).json({ message: "Item not found" });
      }
      res.json(item);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch item" });
    }
  });

  app.post("/api/items", async (req, res) => {
    try {
      const validatedData = batchItemCreationSchema.parse(req.body);
      const createdItems = [];

      // Create vendor if doesn't exist
      let vendor = await storage.getVendorByName(validatedData.vendorName);
      if (!vendor) {
        vendor = await storage.createVendor({ name: validatedData.vendorName, contactInfo: null });
      }

      // Create items in batch
      for (let i = 0; i < validatedData.quantity; i++) {
        const itemData = {
          itemType: validatedData.itemType,
          vendorName: validatedData.vendorName,
          supplyDate: new Date(validatedData.supplyDate),
          warrantyPeriod: validatedData.warrantyPeriod,
          lastInspectionDate: null,
          conditionStatus: "good",
          inspectionNotes: null,
        };

        const item = await storage.createItem(itemData);
        createdItems.push(item);
      }

      res.json({ items: createdItems, count: createdItems.length });
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: "Failed to create items" });
      }
    }
  });

  app.put("/api/items/:id", async (req, res) => {
    try {
      const validatedData = updateItemSchema.parse(req.body);
      
      // Convert string dates to Date objects and filter undefined values
      const processedData: any = {};
      
      if (validatedData.itemType !== undefined) processedData.itemType = validatedData.itemType;
      if (validatedData.vendorName !== undefined) processedData.vendorName = validatedData.vendorName;
      if (validatedData.warrantyPeriod !== undefined) processedData.warrantyPeriod = validatedData.warrantyPeriod;
      if (validatedData.conditionStatus !== undefined) processedData.conditionStatus = validatedData.conditionStatus;
      if (validatedData.inspectionNotes !== undefined) processedData.inspectionNotes = validatedData.inspectionNotes;
      if (validatedData.qrCodeUrl !== undefined) processedData.qrCodeUrl = validatedData.qrCodeUrl;
      
      // Handle date fields with proper conversion
      if (validatedData.lastInspectionDate !== undefined) {
        processedData.lastInspectionDate = validatedData.lastInspectionDate 
          ? new Date(validatedData.lastInspectionDate)
          : null;
      }
      if (validatedData.supplyDate !== undefined) {
        processedData.supplyDate = validatedData.supplyDate 
          ? new Date(validatedData.supplyDate)
          : validatedData.supplyDate;
      }
      if (validatedData.warrantyExpiryDate !== undefined) {
        processedData.warrantyExpiryDate = validatedData.warrantyExpiryDate 
          ? new Date(validatedData.warrantyExpiryDate)
          : validatedData.warrantyExpiryDate;
      }
      
      const updatedItem = await storage.updateItem(req.params.id, processedData);
      
      if (!updatedItem) {
        return res.status(404).json({ message: "Item not found" });
      }
      
      res.json(updatedItem);
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: "Failed to update item" });
      }
    }
  });

  // QR Code routes
  app.get("/api/qr/:id", async (req, res) => {
    try {
      const item = await storage.getItem(req.params.id);
      if (!item) {
        return res.status(404).json({ message: "Item not found" });
      }

      const qrData = {
        id: item.id,
        type: item.itemType,
        vendor: item.vendorName,
      };

      const qrCodeDataURL = await QRCode.toDataURL(JSON.stringify(qrData));
      res.json({ qrCode: qrCodeDataURL, data: qrData });
    } catch (error) {
      res.status(500).json({ message: "Failed to generate QR code" });
    }
  });

  // Statistics route
  app.get("/api/stats", async (req, res) => {
    try {
      const stats = await storage.getStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch statistics" });
    }
  });

  // Vendors route
  app.get("/api/vendors", async (req, res) => {
    try {
      const vendors = await storage.getVendors();
      res.json(vendors);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch vendors" });
    }
  });

  // Inspections routes
  app.post("/api/inspections", async (req, res) => {
    try {
      const validatedData = insertInspectionSchema.parse(req.body);
      const inspection = await storage.createInspection(validatedData);
      
      // Update item's last inspection date
      await storage.updateItem(validatedData.itemId, {
        lastInspectionDate: validatedData.inspectionDate,
      });
      
      res.json(inspection);
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: "Failed to create inspection" });
      }
    }
  });

  // AI Summary route (proxy to raildash.onrender.com with local fallback)
  app.post("/api/ai/generate-summary", async (req, res) => {
    // Validate request body first
    let validatedData;
    try {
      validatedData = aiSummaryRequestSchema.parse(req.body);
    } catch (validationError) {
      if (validationError instanceof Error && 'issues' in validationError) {
        return res.status(400).json({ message: "Invalid request data", errors: validationError.issues });
      }
      return res.status(400).json({ message: "Invalid request data format" });
    }
    
    try {
      // Try external AI service first with timeout
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 5000); // 5 second timeout

      const response = await fetch("https://raildash.onrender.com/ai/generate-summary", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(validatedData),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`AI service returned ${response.status}`);
      }

      const data = await response.json();
      
      // Validate and normalize external response
      try {
        const validatedResponse = aiSummaryResponseSchema.parse(data);
        res.json(validatedResponse);
      } catch (responseValidationError) {
        // If external response is malformed, fall through to local fallback
        throw new Error("External service returned invalid response format");
      }
    } catch (error) {
      // Fallback to local AI-like summary generation
      console.log("AI service unavailable, using local fallback");
      
      const { itemId, itemType, vendor, supplyDate, warrantyPeriod, lastInspection, condition } = validatedData;
      
      // Generate intelligent summary based on item data
      const supplyAge = Math.floor((Date.now() - new Date(supplyDate).getTime()) / (1000 * 60 * 60 * 24 * 30));
      const warrantyRemaining = warrantyPeriod - supplyAge;
      const lastInspectionAge = lastInspection 
        ? Math.floor((Date.now() - new Date(lastInspection).getTime()) / (1000 * 60 * 60 * 24))
        : null;

      let summary = `Item Analysis Report for ${itemId}:\n\n`;
      
      // Basic item info
      summary += `This ${itemType.replace('-', ' ')} was supplied by ${vendor} approximately ${supplyAge} months ago. `;
      
      // Warranty status
      if (warrantyRemaining > 0) {
        summary += `The item is currently under warranty with ${warrantyRemaining} months remaining. `;
      } else {
        summary += `The warranty period has expired ${Math.abs(warrantyRemaining)} months ago. `;
      }
      
      // Condition assessment
      const conditionLower = condition?.toLowerCase();
      if (conditionLower === 'excellent') {
        summary += `The current condition is excellent, indicating optimal maintenance and minimal wear. `;
      } else if (conditionLower === 'good') {
        summary += `The current condition is reported as good, indicating proper maintenance and usage. `;
      } else if (conditionLower === 'fair') {
        summary += `The condition is fair, suggesting some wear but still functional. Consider increased monitoring. `;
      } else if (conditionLower === 'poor') {
        summary += `The condition is poor and requires immediate attention for safety and operational purposes. `;
      }
      
      // Inspection status
      if (lastInspectionAge !== null) {
        if (lastInspectionAge < 30) {
          summary += `Recent inspection (${lastInspectionAge} days ago) indicates proactive maintenance scheduling. `;
        } else if (lastInspectionAge < 90) {
          summary += `Last inspection was ${lastInspectionAge} days ago, within acceptable maintenance intervals. `;
        } else {
          summary += `Last inspection was ${lastInspectionAge} days ago, consider scheduling a new inspection soon. `;
        }
      } else {
        summary += `No inspection record found - recommend scheduling an initial inspection for safety compliance. `;
      }
      
      // Recommendations
      summary += `\n\nRecommendations:\n`;
      if (warrantyRemaining <= 6 && warrantyRemaining > 0) {
        summary += `• Warranty expires soon - document any issues before expiration\n`;
      }
      if (lastInspectionAge === null || lastInspectionAge > 90) {
        summary += `• Schedule inspection to ensure safety standards\n`;
      }
      if (conditionLower !== 'good' && conditionLower !== 'excellent') {
        summary += `• Monitor condition closely and plan maintenance activities\n`;
      }
      summary += `• Maintain proper documentation for railway safety compliance\n`;
      summary += `• Regular QR code verification for tracking accuracy`;

      const localResponse = {
        summary,
        source: "local_analysis",
        generated_at: new Date().toISOString()
      };

      // Validate local response matches expected schema
      const validatedLocalResponse = aiSummaryResponseSchema.parse(localResponse);
      res.json(validatedLocalResponse);
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
